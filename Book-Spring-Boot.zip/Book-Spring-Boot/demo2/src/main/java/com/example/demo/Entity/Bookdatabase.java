package com.example.demo.Entity;

import java.util.Arrays;
import java.util.List;

public class Bookdatabase {

    public static List<Book> getAllBooks() {
        Book Book1 = new Book(1L,"The Tale Of Fake People","Cheetan Bhagat","What’s the difference between ersatz food and tainted or adulterated food? Typically, it’s a matter of information awareness, but in war knowledge can be a dangerous thing. In Kiernan’s book, the protagonist Emma, a baker in occupied France in 1944, pulls a bit of a Robin Hood, taking part of the extra ration of flour she’s supposed to use to bake bread for the Nazis and mixing it with ground straw to feed her starving neighbors.In times of ration and embargo, to survive, and more than survive but thrive, requires creativity and suspension of disbelief. Until meat, flour, sugar, and olive oil were in short supply, peanuts, potato bread, sorghum, and sunflower seed oil were not common items in the Western diet. Though straw bread is not something we eat today, the duress of deprivation and the acts of culinary desperation it inspires can have long-lasting effects, not just on individuals’ lives, but on culture for generations to come.", 2,4,"Fake People","data:image/png;base64,https://www.shutterstock.com/image-photo/mystery-man-holding-black-white-mask-691628098");

        List<Book> books = Arrays.asList(Book1);

        return books;
    }
}
