package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="customers")
public class CustomerModel {
	
	

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerId;


	private String CustomerName;
	
	private String StartDate;
	
	private String EndDate;
	
	private String productA;
	
	private String productB;
	
	private int InvoiceGST;
	
	private int CGST;
	
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return CustomerName;
	}

	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public String getStartDate() {
		return StartDate;
	}

	public void setStartDate(String startDate) {
		StartDate = startDate;
	}

	public String getEndDate() {
		return EndDate;
	}

	public void setEndDate(String endDate) {
		EndDate = endDate;
	}

	public String getProductA() {
		return productA;
	}

	public void setProductA(String productA) {
		this.productA = productA;
	}

	public String getProductB() {
		return productB;
	}

	public void setProductB(String productB) {
		this.productB = productB;
	}

	public int getInvoiceGST() {
		return InvoiceGST;
	}

	public void setInvoiceGST(int invoiceGST) {
		InvoiceGST = invoiceGST;
	}

	public int getCGST() {
		return CGST;
	}

	public void setCGST(int cGST) {
		CGST = cGST;
	}

	@Override
	public String toString() {
		return "CustomerModel [CustomerName=" + CustomerName + ", StartDate=" + StartDate + ", EndDate=" + EndDate
				+ ", productA=" + productA + ", productB=" + productB + ", InvoiceGST=" + InvoiceGST + ", CGST=" + CGST
				+ "]";
	}

	
}
