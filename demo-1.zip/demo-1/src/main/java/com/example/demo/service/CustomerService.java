package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.demo.model.CustomerModel;
import com.example.demo.repository.CustomerRepository;

public abstract class CustomerService {


    @Autowired
    CustomerRepository customerRepository;

    public abstract List<CustomerModel>  getAllCustomers();

    public void save(CustomerModel customers){

    }



    public  void deleteById(int customerId){

    }


    
}
