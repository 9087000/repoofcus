package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.CustomerModel;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerServiceImpl extends CustomerService{

	@Autowired
    CustomerRepository customerRepository;

    @Override
    public List<CustomerModel> getAllCustomers() {
        return customerRepository.findAll();
    }

    public void save(CustomerModel customers) {
        if(Objects.nonNull(customers)){
           customerRepository.save(customers);
        }
    }



    public void deleteById(int customerId) {
            customerRepository.deleteById(customerId);
    }

	

}
