package com.example.demo.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.CustomerModel;
import com.example.demo.service.CustomerService;


public class CustomerController {
	
	 @Autowired
	 public CustomerService customerService;
	
	@GetMapping("/")
	public String loginPage(Model model) {
		  return "login";
	  }

	@GetMapping("/admin/products")
	public String getproduct(Model model) {
		model.addAttribute("allcustomerslist", customerService.getAllCustomers());
		return "products";
	}
	
	
	@GetMapping("/addadminProduct")
    public String addProudctForm(Model model) {
        CustomerModel customers = new CustomerModel();
        model.addAttribute("CustomerModal", customers);
        return "productsAdd";
    }

    @PostMapping("/register")
    public String proudctRegister(@ModelAttribute("customerId") CustomerModel customerModel){
        customerService.save(customerModel);
        return "redirect:/view";
    }


    @GetMapping("/delete/{customerId}")
    public String deleteProd(@PathVariable(value = "customerId") int customerId){
        customerService.deleteById(customerId);
        return "redirect:/view";
    }
	
	
	
	
	
}
