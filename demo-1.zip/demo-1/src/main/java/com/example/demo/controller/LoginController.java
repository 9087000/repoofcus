package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import demothymeleaf.form.java.LoginForm;

import org.springframework.web.bind.annotation.ModelAttribute;



@Controller

public class LoginController {
	
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String getLoginForm() {
		
		
		return "login";
	}

	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String login(@ModelAttribute(name="loginForm")LoginForm  loginForm, Model model) {
		
		int UserId=loginForm.getUserId();
		String Password=loginForm.getPassword();
		
		if(UserId==19324 && "admin".equals(Password)) {
			
			return "products";
		}
		
		model.addAttribute("invalidCredentials",true);
		
		
		return "login";
		
		
	}
	
	
	
}


