package demothymeleaf.form.java;

public class LoginForm {

	
	private int UserId;
	private String Password;
	public LoginForm() {
		super();
		
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int UserId) {
		this.UserId = UserId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String Password) {
		this.Password = Password;
	}
	
}
