package com.Profile.demo.common;

public interface Constant {
    interface USER_TYPE{
        String NORMAL = "NORMAL";
        String ADMIN = "ADMIN";
    }
}
