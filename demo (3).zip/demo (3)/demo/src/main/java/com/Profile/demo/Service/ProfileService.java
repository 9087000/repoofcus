package com.Profile.demo.Service;

import com.Profile.demo.model.Profile;

import java.util.List;

public interface ProfileService {

    public Profile saveProfile(Profile profile);

    public List<Profile> getAllProfiles();

    public Profile getProfileById(Integer id);

    public String deleteProfile(Integer id);

    public Profile editProfile(Profile profile,Integer id);
}
