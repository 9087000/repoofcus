package com.Profile.demo.Controller;


import com.Profile.demo.Service.ProfileService;
import com.Profile.demo.Utility.FileUploadUtil;
import com.Profile.demo.model.Profile;
import com.Profile.demo.model.ProfileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    @PostMapping("/saveProfile")
    public ResponseEntity<?> saveProfile(@RequestBody Profile profile) {
        return new ResponseEntity<>(profileService.saveProfile(profile), HttpStatus.CREATED);
    }

    @PostMapping("/uploadFile")
    public ResponseEntity<ProfileUpload> uploadFile(
            @RequestParam("file") MultipartFile multipartFile)
            throws IOException {

        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        long size = multipartFile.getSize();

        String filecode = FileUploadUtil.saveFile(fileName, multipartFile);

        ProfileUpload response = new ProfileUpload();
        response.setActiveProfile(fileName);
        response.setSize(size);
        response.setDownloadURI("/downloadFile/" + filecode);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/")
    public ResponseEntity<?> getAllProfile() {
        return new ResponseEntity<>(profileService.getAllProfiles(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getProfileById(@PathVariable Integer id) {
        return new ResponseEntity<>(profileService.getProfileById(id), HttpStatus.OK);
    }

    @GetMapping("/deleteProfile/{id}")
    public ResponseEntity<?> deleteProfile(@PathVariable Integer id) {
        return new ResponseEntity<>(profileService.deleteProfile(id), HttpStatus.OK);
    }

    @PostMapping("/editProfile/{id}")
    public ResponseEntity<?> editProfile(@RequestBody Profile profile, @PathVariable Integer id) {
        return new ResponseEntity<>(profileService.editProfile(profile, id), HttpStatus.CREATED);
    }

}


