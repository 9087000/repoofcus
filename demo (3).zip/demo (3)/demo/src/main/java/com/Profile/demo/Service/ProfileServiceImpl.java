package com.Profile.demo.Service;


import com.Profile.demo.Repository.ProfileRepository;
import com.Profile.demo.model.Profile;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProfileServiceImpl implements ProfileService{

      @Autowired
      private ProfileRepository profileRepository;


    @Override
    public Profile saveProfile(Profile profile) {
        return profileRepository.save(profile);
    }



    @Override
    public List<Profile> getAllProfiles() {
        return profileRepository.findAll();
    }

    @Override
    public Profile getProfileById(Integer id) {
        return profileRepository.findById(id).get();
    }

    @Override
    public String deleteProfile(Integer id) {
        Profile profile = profileRepository.findById(id).get();

        if (profile != null) {
            profileRepository.delete(profile);
            return "Profile Deleted Sucessfully";
        }

        return "Something wrong on server";
    }

    @Override
    public Profile editProfile(Profile profile, Integer id) {
        Profile oldProfile = profileRepository.findById(id).get();

        oldProfile.setProfileName(profile.getProfileName());
        oldProfile.setSkills(profile.getSkills());
        oldProfile.setReusability(profile.getReusability());
        oldProfile.setStatus(profile.getStatus());

        return profileRepository.save(oldProfile);
    }
}
