package com.Profile.demo.model;

public class LoginDto {
}
