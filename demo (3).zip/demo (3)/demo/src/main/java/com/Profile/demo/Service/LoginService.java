package com.Profile.demo.Service;

import com.Profile.demo.Dto.LoginRequestDTO;
import com.Profile.demo.Dto.SignUpRequestDTO;
import com.Profile.demo.Repository.UserRepository;
import com.Profile.demo.Utils.JwtUtils;
import com.Profile.demo.common.APIResponse;
import com.Profile.demo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;


    @Service
    public class LoginService {

        @Autowired
        private UserRepository userRepository;
        @Autowired
        private JwtUtils jwtUtils;

        public APIResponse signUp(SignUpRequestDTO signUpRequestDTO) {
            APIResponse apiResponse = new APIResponse();


            User userEntity = new User();
            userEntity.setName(signUpRequestDTO.getName());
            userEntity.setEmailId(signUpRequestDTO.getEmailId());
            userEntity.setActive(Boolean.TRUE);
            userEntity.setGender(signUpRequestDTO.getGender());
            userEntity.setPhoneNumber(signUpRequestDTO.getPhoneNumber());
            userEntity.setPassword(signUpRequestDTO.getPassword());


            userEntity = userRepository.save(userEntity);


            //String token = jwtUtils.generateJwt(userEntity);

            //Map<String, Object> data = new HashMap<>();
            //data.put("accessToken", token);

            apiResponse.setData(userEntity);


            return apiResponse;
        }

        public APIResponse login(LoginRequestDTO loginRequestDTO) {

            APIResponse apiResponse = new APIResponse();

            // validation

            // verify user exist with given email and password
            User user = userRepository.findOneByEmailIdIgnoreCaseAndPassword(loginRequestDTO.getEmailId(), loginRequestDTO.getPassword());

            // response
            if (user == null) {
                apiResponse.setData("User login failed");
                return apiResponse;
            }

            // generate jwt
            String token = jwtUtils.generateJwt(user);

            Map<String, Object> data = new HashMap<>();
            data.put("accessToken", token);

            apiResponse.setData(data);

            return apiResponse;
        }
    }