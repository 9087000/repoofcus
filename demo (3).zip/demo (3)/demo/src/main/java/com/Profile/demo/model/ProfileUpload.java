package com.Profile.demo.model;

public class ProfileUpload {

    private String ActiveProfile;
    private String downloadURI;
    private long Size;

    public String getActiveProfile() {
        return ActiveProfile;
    }

    public void setActiveProfile(String activeProfile) {
        ActiveProfile = activeProfile;
    }


    public String getDownloadURI() {
        return downloadURI;
    }

    public void setDownloadURI(String downloadURI) {
        this.downloadURI = downloadURI;
    }

    public long getSize() {
        return Size;
    }

    public void setSize(long size) {
        Size = size;
    }
}
